The flask backend to support breast, lung and prostate cancer prediction using a website as UI 
