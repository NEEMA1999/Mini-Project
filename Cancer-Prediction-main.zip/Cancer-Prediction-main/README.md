# Cancer-Prediction
A website for predicting cancer(Prostate, Lung, Breast cancer).
